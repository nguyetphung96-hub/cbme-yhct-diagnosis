// Core inference pipeline (placeholder)
export function infer(caseData) {
  return { diagnosis: [] };
}
