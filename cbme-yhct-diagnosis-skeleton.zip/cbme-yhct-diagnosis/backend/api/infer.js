// API entry point
export default async function handler(req, res) {
  res.json({ status: 'ok' });
}
