# CBME YHCT Diagnosis App

Repo skeleton for CBME-based YHCT diagnosis system.